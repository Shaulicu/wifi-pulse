# WiFi Pulse — Android app

A small native Android Java app with a dark dashboard showing the **currently connected Wi-Fi** SSID, RSSI, frequency, negotiated link speed, IPv4 address, and BSSID. Updates every 3 seconds while open. No ads, accounts, analytics, internet permission, or external dependencies.

## Build + install

1. Install current **Android Studio** and its Android SDK Platform **35**.
2. Open the `WifiPulse` directory as a Gradle project.
3. Allow Android Studio to sync/download **Android Gradle Plugin 8.7.3** and **Gradle 8.9**. (No wrapper JAR included; Android Studio can use its configured Gradle or generate a wrapper.)
4. Connect an Android device with USB debugging, then press **Run** in Android Studio.
5. Or use **Build > Build APK(s)** and install `app/build/outputs/apk/debug/app-debug.apk` on your phone.

## Permissions and limitations

* **Precise location** permission and the device's **Location** toggle are required by Android to reveal SSID/BSSID on many devices. The app itself does not read GPS position.
* The app only **reads** connection information; it does not scan nearby Wi-Fi or control Wi-Fi.
* Negotiated **link speed** is not internet download speed.
* Some vendor Android builds redact the SSID, BSSID, or other information even when connected.
* Android 8.0+ (API 26), optimized for recent Android versions.
* This source project has **not** been compiled or tested on an actual device in the provided environment because Android SDK/Gradle are unavailable.
